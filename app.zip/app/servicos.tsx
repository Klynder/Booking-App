
import { Servicos } from '@/constants/servicos';
import { Link } from 'expo-router';
import { useEffect, useState } from 'react';
import { Image, StyleSheet, Platform, Text, FlatList, View, Pressable } from 'react-native';

type Servicos = {
  id_servico:number;
  descricao:string;
  valor:number;
}


export default function HomeScreen() {
   
  const [servicos, setServicos] = useState<Servicos[] | null>(null);
    
    useEffect(() => {
  
      const getUsuarios = async () => {
        try {
          const response = await fetch('http://localhost/laravelnoite/estrutura_laravel-main/servicos');
          // const response = await fetch('https://novo.mobi-rio.rio.br/get-avisos');
          const data = await response.json();
          setServicos(data.servicos);
          console.error('users:', data.usuarios);
        } catch (error) {
          console.error('Erro ao buscar usuários:', error);
        }
      };
  
      getUsuarios();
    }, []);
  return (

    <View style={styles.container}>

      <Text style={styles.title}>Perfis de Clientes</Text>
      <FlatList
        data={servicos}
        keyExtractor={(item) => item.id_servico.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text>Id: {item.id_servico}</Text>
            <Text>descricao: {item.descricao}</Text>
            <Text>valor: {item.valor}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f8f8f8',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  card: {
    backgroundColor: 'white',
    padding: 15,
    marginVertical: 8,
    borderRadius: 10,
    boxShadowColor: '#000',
    boxShadowOffset: { width: 0, height: 2 },
    boxShadowOpacity: 0.1,
    boxShadowRadius: 4,
    elevation: 3,
  },
  nome: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});